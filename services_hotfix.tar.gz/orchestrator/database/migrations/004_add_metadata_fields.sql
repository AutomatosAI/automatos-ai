-- Migration to add missing metadata fields
-- Run this to fix the MetaData assignment error

-- Add execution_metadata column to workflow_executions table (metadata is reserved in SQLAlchemy)
ALTER TABLE workflow_executions 
ADD COLUMN IF NOT EXISTS execution_metadata JSON DEFAULT '{}';

-- Add models_used column for tracking model usage
ALTER TABLE workflow_executions 
ADD COLUMN IF NOT EXISTS models_used JSON DEFAULT '[]';

-- Add last_execution column to workflows table for quick access
ALTER TABLE workflows 
ADD COLUMN IF NOT EXISTS last_execution JSON;

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_workflow_executions_metadata ON workflow_executions USING GIN (metadata);
CREATE INDEX IF NOT EXISTS idx_workflows_last_execution ON workflows USING GIN (last_execution);

-- Update any existing executions with empty metadata
UPDATE workflow_executions 
SET metadata = '{}' 
WHERE metadata IS NULL;
