
"""
MCP Server for Multi-Agent Orchestration System
===============================================

Provides headless MCP server interface for IDE integration with:
- Workflow management
- Document management  
- Context engineering
- SSH command execution
- Progress tracking
"""
